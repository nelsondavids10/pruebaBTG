package com.javasampleapproach.springrest.mongodb.model;
//packdescription com.javasampleapproach.springrest.mongodb.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "PQR")
public class PQR {
	@Id
	private String id;

	private String pqr;
	private int description;
	private boolean active;

	public PQR() {
	}

	public PQR(String pqr, int description) {
		this.pqr = pqr;
		this.description = description;
	}

	public String getId() {
		return id;
	}

	public void setpqr(String pqr) {
		this.pqr = pqr;
	}

	public String getpqr() {
		return this.pqr;
	}

	public void setdescription(int description) {
		this.description = description;
	}

	public int getdescription() {
		return this.description;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "PQR [id=" + id + ", pqr=" + pqr + ", description=" + description + ", active=" + active + "]";
	}
}
