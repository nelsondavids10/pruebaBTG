package com.javasampleapproach.springrest.mongodb.repo;

//packdescription com.javasampleapproach.springrest.mongodb.repo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.javasampleapproach.springrest.mongodb.model.PQR;

public interface PQRRepository extends MongoRepository<PQR, String>{
	List<PQR> findBydescription(int description);
}
