package com.javasampleapproach.springrest.mongodb.controller;
//packdescription com.javasampleapproach.springrest.mongodb.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.springrest.mongodb.model.PQR;
import com.javasampleapproach.springrest.mongodb.repo.PQRRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class PQRController {

	@Autowired
	PQRRepository repository;

	@GetMapping("/PQRs")
	public List<PQR> getAllPQRs() {
		System.out.println("Get all PQRs...");

		List<PQR> PQRs = new ArrayList<>();
		repository.findAll().forEach(PQRs::add);

		return PQRs;
	}

	@PostMapping("/PQRs/create")
	public PQR postPQR(@RequestBody PQR PQR) {

		PQR _PQR = repository.save(new PQR(PQR.getpqr(), PQR.getdescription()));
		return _PQR;
	}

	@DeleteMapping("/PQRs/{id}")
	public ResponseEntity<String> deletePQR(@PathVariable("id") String id) {
		System.out.println("Delete PQR with ID = " + id + "...");

		repository.deleteById(id);

		return new ResponseEntity<>("PQR has been deleted!", HttpStatus.OK);
	}

	@DeleteMapping("/PQRs/delete")
	public ResponseEntity<String> deleteAllPQRs() {
		System.out.println("Delete All PQRs...");

		repository.deleteAll();

		return new ResponseEntity<>("All PQRs have been deleted!", HttpStatus.OK);
	}

	@GetMapping("PQRs/description/{description}")
	public List<PQR> findBydescription(@PathVariable int description) {

		List<PQR> PQRs = repository.findBydescription(description);
		return PQRs;
	}

	@PutMapping("/PQRs/{id}")
	public ResponseEntity<PQR> updatePQR(@PathVariable("id") String id, @RequestBody PQR PQR) {
		System.out.println("Update PQR with ID = " + id + "...");

		Optional<PQR> PQRData = repository.findById(id);

		if (PQRData.isPresent()) {
			PQR _PQR = PQRData.get();
			_PQR.setpqr(PQR.getpqr());
			_PQR.setdescription(PQR.getdescription());
			_PQR.setActive(PQR.isActive());
			return new ResponseEntity<>(repository.save(_PQR), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
