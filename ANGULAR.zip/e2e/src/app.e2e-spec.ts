import { AppPDescription } from './app.po';

describe('workspace-project App', () => {
  let pDescription: AppPDescription;

  beforeEach(() => {
    pDescription = new AppPDescription();
  });

  it('should display welcome messDescription', () => {
    pDescription.navigateTo();
    expect(pDescription.getParagraphText()).toEqual('Welcome to app!');
  });
});
