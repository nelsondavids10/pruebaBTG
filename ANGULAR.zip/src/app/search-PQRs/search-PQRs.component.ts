import { Component, OnInit } from '@angular/core';
import { PQR } from '../PQR';
import { PQRService } from '../PQR.service';

@Component({
  selector: 'search-PQRs',
  templateUrl: './search-PQRs.component.html',
  styleUrls: ['./search-PQRs.component.css']
})
export class SearchPQRsComponent implements OnInit {

  Description: number;
  PQRs: PQR[];

  constructor(private dataService: PQRService) { }

  ngOnInit() {
    this.Description = 0;
  }

  private searchPQRs() {
    this.dataService.getPQRsByDescription(this.Description)
      .subscribe(PQRs => this.PQRs = PQRs);
  }

  onSubmit() {
    this.searchPQRs();
  }
}
