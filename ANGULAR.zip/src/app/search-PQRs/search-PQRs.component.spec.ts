import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchPQRsComponent } from './search-PQRs.component';

describe('SearchPQRsComponent', () => {
  let component: SearchPQRsComponent;
  let fixture: ComponentFixture<SearchPQRsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchPQRsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPQRsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
