import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePQRComponent } from './create-PQR.component';

describe('CreatePQRComponent', () => {
  let component: CreatePQRComponent;
  let fixture: ComponentFixture<CreatePQRComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePQRComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePQRComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
