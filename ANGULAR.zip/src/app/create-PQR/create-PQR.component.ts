import { Component, OnInit } from '@angular/core';

import { PQR } from '../PQR';
import { PQRService } from '../PQR.service';

@Component({
  selector: 'create-PQR',
  templateUrl: './create-PQR.component.html',
  styleUrls: ['./create-PQR.component.css']
})
export class CreatePQRComponent implements OnInit {

  PQR: PQR = new PQR();
  submitted = false;

  constructor(private PQRService: PQRService) { }

  ngOnInit() {
  }

  newPQR(): void {
    this.submitted = false;
    this.PQR = new PQR();
  }

  save() {
    this.PQRService.createPQR(this.PQR)
      .subscribe(data => console.log(data), error => console.log(error));
    this.PQR = new PQR();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}
