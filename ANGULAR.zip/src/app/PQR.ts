export class PQR {
    id: number;
    Type: string;
    Description: number;
    active: boolean;
}
