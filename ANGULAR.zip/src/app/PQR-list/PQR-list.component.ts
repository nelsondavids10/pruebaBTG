import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { PQRService } from '../PQR.service';
import { PQR } from '../PQR';

@Component({
  selector: 'PQRs-list',
  templateUrl: './PQRs-list.component.html',
  styleUrls: ['./PQRs-list.component.css']
})
export class PQRsListComponent implements OnInit {

  PQRs: Observable<PQR[]>;

  constructor(private PQRService: PQRService) { }

  ngOnInit() {
    this.reloadData();
  }

  deletePQRs() {
    this.PQRService.deleteAll()
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log('ERROR: ' + error));
  }

  reloadData() {
    this.PQRs = this.PQRService.getPQRsList();
  }
}
