import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PQRsListComponent } from './PQRs-list.component';

describe('PQRsListComponent', () => {
  let component: PQRsListComponent;
  let fixture: ComponentFixture<PQRsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PQRsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PQRsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
