import { TestBed, inject } from '@angular/core/testing';

import { PQRService } from './PQR.service';

describe('PQRService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PQRService]
    });
  });

  it('should be created', inject([PQRService], (service: PQRService) => {
    expect(service).toBeTruthy();
  }));
});
