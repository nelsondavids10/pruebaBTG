import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PQRService {

  private baseUrl = 'http://localhost:8080/api/PQRs';

  constructor(private http: HttpClient) { }

  getPQR(id: number): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createPQR(PQR: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/create`, PQR);
  }

  updatePQR(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deletePQR(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getPQRsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

  getPQRsByDescription(Description: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/Description/${Description}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(`${this.baseUrl}` + `/delete`, { responseType: 'text' });
  }
}
