import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { CreatePQRComponent } from './create-PQR/create-PQR.component';
import { PQRDetailsComponent } from './PQR-details/PQR-details.component';
//import { PQRsListComponent } from './PQRs-list/PQRs-list.component';
import { SearchPQRsComponent } from './search-PQRs/search-PQRs.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { PQRsListComponent } from './PQR-list/PQRs-list.component';

@NgModule({
  declarations: [
    AppComponent,
    CreatePQRComponent,
    PQRDetailsComponent,
    PQRsListComponent,
    SearchPQRsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
