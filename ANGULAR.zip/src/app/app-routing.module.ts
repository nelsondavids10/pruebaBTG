import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
//import { PQRsListComponent } from './PQRs-list/PQRs-list.component';
import { CreatePQRComponent } from './create-PQR/create-PQR.component';
import { PQRsListComponent } from './PQR-list/PQRs-list.component';
import { SearchPQRsComponent } from './search-PQRs/search-PQRs.component';

const routes: Routes = [
    { path: '', redirectTo: 'PQR', pathMatch: 'full' },
    { path: 'PQR', component: PQRsListComponent },
    { path: 'add', component: CreatePQRComponent },
    { path: 'findbyDescription', component: SearchPQRsComponent },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }
