import { Component, OnInit, Input } from '@angular/core';
import { PQRService } from '../PQR.service';
import { PQR } from '../PQR';
import { PQRsListComponent } from '../PQR-list/PQRs-list.component';
//import { PQRsListComponent } from '../PQR-list/PQR-list.component';

//import { PQRsListComponent } from '../PQRs-list/PQRs-list.component';

@Component({
  selector: 'PQR-details',
  templateUrl: './PQR-details.component.html',
  styleUrls: ['./PQR-details.component.css']
})
export class PQRDetailsComponent implements OnInit {

  @Input() PQR: PQR;

  constructor(private PQRService: PQRService, private listComponent: PQRsListComponent) { }

  ngOnInit() {
  }

  updateActive(isActive: boolean) {
    this.PQRService.updatePQR(this.PQR.id,
      { Type: this.PQR.Type, Description: this.PQR.Description, active: isActive })
      .subscribe(
        data => {
          console.log(data);
          this.PQR = data as PQR;
        },
        error => console.log(error));
  }

  deletePQR() {
    this.PQRService.deletePQR(this.PQR.id)
      .subscribe(
        data => {
          console.log(data);
          this.listComponent.reloadData();
        },
        error => console.log(error));
  }
}
